function AnalysisPanel({ data, loading }) {
  const decision = data?.decision || null
  const quality = data?.dataQuality || data?.data_quality || null

  return (
    <section className="rounded-2xl border border-slate-800 bg-slate-950/70 p-6">
      <p className="text-sm uppercase tracking-widest text-cyan-400">
        Analysis
      </p>

      <h2 className="mt-2 text-2xl font-bold">
        Intelligence Assessment
      </h2>

      {loading ? (
        <p className="mt-6 text-slate-400">
          Analysis is being processed...
        </p>
      ) : decision ? (
        <>
          <p className="mt-6 text-slate-300">
            {decision.recommendation || 'Recommendation available.'}
          </p>

          {decision.key_reasons?.length > 0 && (
            <div className="mt-4">
              <p className="text-sm text-slate-400">Key Reasons</p>

              <ul className="mt-2 list-disc space-y-1 pl-5 text-slate-300">
                {decision.key_reasons.map((reason, index) => (
                  <li key={index}>{reason}</li>
                ))}
              </ul>
            </div>
          )}

          <div className="mt-6 grid grid-cols-2 gap-6">
            <div>
              <p className="text-sm text-slate-400">Data Quality</p>
              <p className="mt-2 text-xl font-semibold text-white">
                {Array.isArray(quality)
                  ? quality.join(', ') || '--'
                  : quality || '--'}
              </p>
            </div>

            <div>
              <p className="text-sm text-slate-400">Confidence</p>
              <p className="mt-2 text-xl font-semibold text-white">
                {decision.confidence ?? '--'}
              </p>
            </div>
          </div>
        </>
      ) : (
        <p className="mt-6 text-slate-400">
          Assessment will appear when analysis results are available.
        </p>
      )}
    </section>
  )
}

export default AnalysisPanel